export * from './config-navigation';

export { default as ComponentHero } from './ComponentHero';
export { default as ComponentCard } from './ComponentCard';
