export { default as useLocales } from './useLocales';

export { default } from './ThemeLocalization';
